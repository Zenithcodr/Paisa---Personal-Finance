"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  Check,
  ChevronRight,
  Download,
  FlaskConical,
  Goal,
  HandCoins,
  History,
  IndianRupee,
  Landmark,
  Pause,
  Play,
  Plus,
  ReceiptText,
  RotateCcw,
  Search,
  ShieldCheck,
  Sparkles,
  Target,
  Trash2,
  TrendingDown,
  Upload,
  WalletCards,
  X,
} from "lucide-react";
import {
  applyScenario,
  formatINR,
  getForecast,
  getMetrics,
  simulateDecision,
} from "@/lib/engine";
import { scenarioPresets, seedState } from "@/lib/seed";
import { MAX_IMPORT_BYTES, parseMoneyState } from "@/lib/validation";
import { useModalDialog } from "@/components/use-modal-dialog";
import { BudgetRing } from "@/components/dashboard/BudgetRing";
import { CategoryBreakdown } from "@/components/dashboard/CategoryBreakdown";
import { SpendingMatrix } from "@/components/calendar/SpendingMatrix";
import { GoalImpactCard } from "@/components/what-if/GoalImpactCard";
import { GoalLockboxSimulator } from "@/components/goals/GoalLockboxSimulator";
import { HealthAdvice } from "@/components/health/HealthAdvice";
import type {
  Category,
  ForecastDay,
  MoneyState,
  Scenario,
  Transaction,
  TransactionType,
} from "@/lib/types";

type Tab = "today" | "simulate" | "calendar" | "goals" | "ledger";
const STORAGE_KEY = "bbf-state-v1";
const tabs: { id: Tab; label: string; icon: typeof Landmark }[] = [
  { id: "today", label: "Today", icon: Landmark },
  { id: "simulate", label: "What-If Lab", icon: FlaskConical },
  { id: "calendar", label: "30-Day Map", icon: CalendarDays },
  { id: "goals", label: "Goals & Subs", icon: Goal },
  { id: "ledger", label: "Ledger", icon: ReceiptText },
];
const categoryLabels: Record<Category, string> = {
  needs: "Needs",
  groceries: "Groceries",
  food: "Food",
  transport: "Transport",
  subscriptions: "Subscriptions",
  utilities: "Utilities",
  fun: "Fun",
  social: "Social",
  health: "Health",
  education: "Education",
  emergency: "Emergency",
  income: "Income",
  savings: "Savings",
  debt: "Debt",
};

function safeLoad(): { state: MoneyState; restored: boolean } {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { state: seedState, restored: false };
    const parsed = parseMoneyState(JSON.parse(raw));
    if (!parsed) throw new Error("bad shape");
    return { state: parsed, restored: false };
  } catch {
    localStorage.removeItem(STORAGE_KEY);
    return { state: seedState, restored: true };
  }
}

export function MoneyApp() {
  const [state, setState] = useState<MoneyState>(seedState);
  const [tab, setTab] = useState<Tab>("today");
  const [scenario, setScenario] = useState<Scenario>(scenarioPresets[0]);
  const [ready, setReady] = useState(false);
  const [toast, setToast] = useState("");
  const [notice, setNotice] = useState("");
  const [receipt, setReceipt] = useState<ReturnType<
    typeof simulateDecision
  > | null>(null);
  const [addOpen, setAddOpen] = useState<"expense" | "income" | null>(null);
  const [history, setHistory] = useState<MoneyState[]>([]);
  const [selectedDay, setSelectedDay] = useState(state.profile.currentDay);
  const importRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    const loaded = safeLoad();
    setState(loaded.state);
    setSelectedDay(loaded.state.profile.currentDay);
    setReady(true);
    if (loaded.restored)
      setNotice("Saved data looked broken, so we restored the demo month.");
  }, []);
  useEffect(() => {
    if (ready) localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state, ready]);
  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(""), 3200);
    return () => clearTimeout(id);
  }, [toast]);
  const forecast = useMemo(() => getForecast(state), [state]);
  const metrics = useMemo(() => getMetrics(state, forecast), [state, forecast]);
  const simulation = useMemo(
    () => simulateDecision(state, scenario),
    [state, scenario],
  );
  const updateState = (fn: (s: MoneyState) => MoneyState, message: string) => {
    setHistory((h) => [structuredClone(state), ...h].slice(0, 8));
    setState(fn(structuredClone(state)));
    setToast(message);
  };
  const commit = () => {
    const result = simulateDecision(state, scenario);
    updateState(
      (s) => applyScenario(s, scenario),
      scenario.kind.includes("subscription")
        ? "Subscription updated. The month recalculated."
        : "Decision applied. Every number is now up to date.",
    );
    setReceipt(result);
  };
  const undo = () => {
    const previous = history[0];
    if (!previous) return;
    setState(previous);
    setHistory((h) => h.slice(1));
    setToast("Last decision undone.");
  };
  const reset = () => {
    setHistory([structuredClone(state)]);
    setState(structuredClone(seedState));
    setScenario(scenarioPresets[0]);
    setToast("Demo month reset to Day 8.");
  };
  const exportData = () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "broke-but-functional.json";
    a.click();
    URL.revokeObjectURL(url);
  };
  const importData = async (file?: File) => {
    if (!file) return;
    try {
      if (file.size > MAX_IMPORT_BYTES || !/json$/i.test(file.name))
        throw new Error();
      const data = parseMoneyState(JSON.parse(await file.text()));
      if (!data) throw new Error();
      updateState(() => data, "Money data imported safely.");
    } catch {
      setToast("Import rejected: choose a valid BBF JSON file under 256 KB.");
    }
  };

  return (
    <div className="app-shell">
      <a className="skip-link" href="#main-content">
        Skip to main content
      </a>
      <Sidebar tab={tab} setTab={setTab} metrics={metrics} />
      <main className="main" id="main-content" tabIndex={-1}>
        <header className="topbar">
          <div>
            <p className="eyebrow">
              DAY {state.profile.currentDay} OF {state.profile.monthLength}
            </p>
            <h1>{tabs.find((t) => t.id === tab)?.label}</h1>
          </div>
          <div className="top-actions">
            <button
              className="icon-btn hide-mobile"
              onClick={undo}
              disabled={!history.length}
              aria-label="Undo last change"
            >
              <RotateCcw size={17} aria-hidden="true" />
            </button>
            <button
              className="icon-btn emergency-trigger"
              onClick={() => {
                setScenario(
                  scenarioPresets.find((item) => item.id === "repair") ??
                    scenarioPresets[0],
                );
                setTab("simulate");
              }}
              aria-label="Run an unexpected expense shock drill"
              title="Life happens: shock drill"
            >
              <AlertTriangle size={17} aria-hidden="true" />
            </button>
            <div className={`risk-pill ${metrics.riskLabel.toLowerCase()}`}>
              <span></span>
              {metrics.riskLabel} · {metrics.riskScore}
            </div>
            <button className="balance-chip" onClick={() => setTab("ledger")}>
              <small>Balance now</small>
              <strong>{formatINR(metrics.currentBalance)}</strong>
            </button>
          </div>
        </header>
        {notice && (
          <div className="notice" role="alert">
            <AlertTriangle size={17} aria-hidden="true" />
            {notice}
            <button
              onClick={() => setNotice("")}
              aria-label="Dismiss data recovery notice"
            >
              <X size={16} aria-hidden="true" />
            </button>
          </div>
        )}
        {tab === "today" && (
          <Today
            state={state}
            metrics={metrics}
            forecast={forecast}
            setTab={setTab}
            openAdd={setAddOpen}
            onSelectDay={(d) => {
              setSelectedDay(d);
              setTab("calendar");
            }}
          />
        )}
        {tab === "simulate" && (
          <Simulate
            state={state}
            scenario={scenario}
            setScenario={setScenario}
            result={simulation}
            onCommit={commit}
          />
        )}
        {tab === "calendar" && (
          <CalendarView
            state={state}
            forecast={forecast}
            selectedDay={selectedDay}
            setSelectedDay={setSelectedDay}
            openAdd={setAddOpen}
          />
        )}
        {tab === "goals" && (
          <GoalsSubs state={state} updateState={updateState} />
        )}
        {tab === "ledger" && (
          <Ledger
            state={state}
            updateState={updateState}
            onExport={exportData}
            onImport={() => importRef.current?.click()}
            onReset={reset}
            openAdd={setAddOpen}
          />
        )}
        <input
          ref={importRef}
          hidden
          type="file"
          accept="application/json"
          onChange={(e) => {
            void importData(e.target.files?.[0]);
            e.target.value = "";
          }}
        />
      </main>
      <MobileNav tab={tab} setTab={setTab} />
      {toast && (
        <div className="toast" role="status" aria-live="polite">
          <Check size={18} aria-hidden="true" />
          <span>{toast}</span>
        </div>
      )}
      {receipt && (
        <DecisionReceipt
          result={receipt}
          scenario={scenario}
          onClose={() => setReceipt(null)}
        />
      )}
      {addOpen && (
        <AddTransaction
          mode={addOpen}
          day={selectedDay}
          currentDay={state.profile.currentDay}
          onClose={() => setAddOpen(null)}
          onAdd={(tx) => {
            updateState(
              (s) => ({ ...s, ledger: [tx, ...s.ledger] }),
              `${addOpen === "income" ? "Income" : "Expense"} added. Forecast recalculated.`,
            );
            setAddOpen(null);
          }}
        />
      )}
    </div>
  );
}

function Sidebar({
  tab,
  setTab,
  metrics,
}: {
  tab: Tab;
  setTab: (t: Tab) => void;
  metrics: ReturnType<typeof getMetrics>;
}) {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark">
          B<span>•</span>
        </div>
        <div>
          <strong>Broke But Functional</strong>
          <small>Survive the month</small>
        </div>
      </div>
      <nav aria-label="Primary navigation">
        {tabs.map((item) => (
          <button
            key={item.id}
            className={tab === item.id ? "active" : ""}
            aria-current={tab === item.id ? "page" : undefined}
            onClick={() => setTab(item.id)}
          >
            <item.icon size={19} aria-hidden="true" />
            <span>{item.label}</span>
            {item.id === "simulate" && <b>LAB</b>}
          </button>
        ))}
      </nav>
      <div className="side-readout">
        <div
          className="score-orbit"
          style={
            {
              "--score": `${metrics.healthScore * 3.6}deg`,
            } as React.CSSProperties
          }
        >
          <div>
            <strong>{metrics.healthScore}</strong>
            <small>/ 100</small>
          </div>
        </div>
        <p>Financial health</p>
        <strong>{metrics.healthLabel}</strong>
        <small>
          {metrics.nextDangerDay
            ? `Buffer breaks on Day ${metrics.nextDangerDay}`
            : "Buffer holds through Day 30"}
        </small>
      </div>
      <p className="side-quote">
        “Your money has a story.
        <br />
        See the ending first.”
      </p>
    </aside>
  );
}

function MobileNav({ tab, setTab }: { tab: Tab; setTab: (t: Tab) => void }) {
  return (
    <nav className="mobile-nav" aria-label="Mobile navigation">
      {tabs.map((t) => (
        <button
          key={t.id}
          className={tab === t.id ? "active" : ""}
          aria-current={tab === t.id ? "page" : undefined}
          onClick={() => setTab(t.id)}
        >
          <t.icon size={20} aria-hidden="true" />
          <span>
            {t.label === "What-If Lab"
              ? "Lab"
              : t.label === "Goals & Subs"
                ? "Goals"
                : t.label === "30-Day Map"
                  ? "Map"
                  : t.label}
          </span>
        </button>
      ))}
    </nav>
  );
}

function Today({
  state,
  metrics,
  forecast,
  setTab,
  openAdd,
  onSelectDay,
}: {
  state: MoneyState;
  metrics: ReturnType<typeof getMetrics>;
  forecast: ForecastDay[];
  setTab: (t: Tab) => void;
  openAdd: (v: "expense" | "income") => void;
  onSelectDay: (d: number) => void;
}) {
  const upcoming = [
    ...state.commitments
      .filter((c) => c.status === "upcoming")
      .map((c) => ({ ...c, kind: "Bill" })),
    ...state.subscriptions
      .filter((s) => s.status === "active")
      .map((s) => ({ ...s, kind: "Subscription" })),
  ]
    .sort((a, b) => a.day - b.day)
    .slice(0, 3);
  const insight = metrics.nextDangerDay
    ? `${formatINR(metrics.committed)} is spoken for. Hold daily spending near ${formatINR(metrics.safeDaily)} to keep the buffer alive past Day ${metrics.nextDangerDay}.`
    : `Your commitments fit and the buffer holds. ${formatINR(metrics.safeDaily)} is safe today without borrowing from future bills.`;
  return (
    <div className="page-stack">
      <section className="hero-grid">
        <div className="safe-hero">
          <div className="hero-kicker">
            <ShieldCheck size={17} /> YOUR SPENDABLE TRUTH
          </div>
          <p>Safe to spend today</p>
          <h2>{formatINR(metrics.safeDaily)}</h2>
          <div className="hero-caption">
            <span>{formatINR(metrics.currentBalance)} in hand</span>
            <ArrowRight size={16} />
            <span>{metrics.daysLeft} days to go</span>
          </div>
          <button className="primary" onClick={() => setTab("simulate")}>
            Test a decision <ArrowUpRight size={17} />
          </button>
          <div className="scribble">without hurting the month</div>
        </div>
        <div className="position-panel">
          <div className="panel-heading">
            <span>Where you stand</span>
            <span className="live-dot">LIVE PLAN</span>
          </div>
          <div className="position-big">
            <small>Projected month-end</small>
            <strong className={metrics.monthEnd < 0 ? "negative" : ""}>
              {formatINR(metrics.monthEnd)}
            </strong>
            <em>
              {metrics.monthEnd >= 0
                ? "Still standing."
                : "Needs a recovery plan."}
            </em>
          </div>
          <div className="mini-grid">
            <Metric
              label="Locked for bills"
              value={formatINR(metrics.committed)}
            />
            <Metric
              label="Shock reserve"
              value={formatINR(metrics.shockReserve)}
            />
            <Metric
              label="Protected savings"
              value={formatINR(metrics.protectedSavings)}
            />
            <Metric label="Runway" value={`${metrics.runway} days`} />
          </div>
        </div>
      </section>
      <section className="timeline-card">
        <div className="section-title">
          <div>
            <p className="eyebrow">THE MONTH AT A GLANCE</p>
            <h2>30-day survival line</h2>
          </div>
          <div className="legend">
            <span className="safe-key">Safe</span>
            <span className="tight-key">Tight</span>
            <span className="danger-key">Danger</span>
          </div>
        </div>
        <DangerStrip state={state} forecast={forecast} onSelect={onSelectDay} />
        <CashflowChart
          forecast={forecast}
          minBuffer={state.profile.minimumBuffer}
        />
      </section>
      <section className="two-col">
        <div className="budget-ring-card">
          <div className="panel-heading">
            <span>Pool Allocation</span>
            <span className="live-dot">₹10,000 CAP</span>
          </div>
          <BudgetRing state={state} metrics={metrics} />
        </div>
        <CategoryBreakdown state={state} />
      </section>
      <HealthAdvice state={state} metrics={metrics} />
      <section className="two-col">
        <div className="insight-card">
          <div className="stamp">
            <Sparkles size={18} /> FIELD NOTE
          </div>
          <h3>
            {metrics.riskLabel === "Danger" || metrics.riskLabel === "Risky"
              ? "The month needs intervention."
              : metrics.riskLabel === "Tight"
                ? "Tight, but workable."
                : "You have breathing room."}
          </h3>
          <p>{insight}</p>
          <button className="text-link" onClick={() => setTab("simulate")}>
            Find a safer move <ArrowRight size={15} />
          </button>
        </div>
        <div className="upcoming">
          <div className="section-title compact">
            <div>
              <p className="eyebrow">NEXT UP</p>
              <h2>Money already promised</h2>
            </div>
            <span>{formatINR(upcoming.reduce((s, x) => s + x.amount, 0))}</span>
          </div>
          {upcoming.map((item) => (
            <div className="upcoming-row" key={item.id}>
              <div className="date-box">
                <strong>{item.day}</strong>
                <small>DAY</small>
              </div>
              <div>
                <strong>{item.label}</strong>
                <small>
                  {item.kind} ·{" "}
                  {"essential" in item && item.essential === false
                    ? "Flexible"
                    : "Essential"}
                </small>
              </div>
              <b>−{formatINR(item.amount)}</b>
            </div>
          ))}
        </div>
      </section>
      <section className="quick-actions">
        <p className="eyebrow">QUICK MOVES</p>
        <div>
          <button onClick={() => openAdd("expense")}>
            <span>
              <Plus size={18} />
            </span>
            Add expense
          </button>
          <button onClick={() => openAdd("income")}>
            <span>
              <IndianRupee size={18} />
            </span>
            Add income
          </button>
          <button onClick={() => setTab("simulate")}>
            <span>
              <FlaskConical size={18} />
            </span>
            Run a what-if
          </button>
          <button onClick={() => setTab("goals")}>
            <span>
              <Pause size={18} />
            </span>
            Pause a subscription
          </button>
        </div>
      </section>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <small>{label}</small>
      <strong>{value}</strong>
    </div>
  );
}

function DangerStrip({
  state,
  forecast,
  scenario,
  onSelect,
}: {
  state: MoneyState;
  forecast: ForecastDay[];
  scenario?: Scenario;
  onSelect?: (d: number) => void;
}) {
  const map = new Map(forecast.map((d) => [d.day, d]));
  return (
    <div className="danger-strip" aria-label="30-day survival status">
      {Array.from({ length: state.profile.monthLength }, (_, i) => i + 1).map(
        (day) => {
          const f = map.get(day);
          return (
            <button
              key={day}
              onClick={() => onSelect?.(day)}
              className={`${day < state.profile.currentDay ? "past" : f?.isDanger ? "danger" : f?.isLow ? "tight" : "safe"} ${day === state.profile.currentDay ? "current" : ""} ${scenario?.day === day ? "scenario" : ""}`}
              title={`Day ${day}${f ? `: ${formatINR(f.balance)} projected` : ""}`}
            >
              <span>{day}</span>
            </button>
          );
        },
      )}
    </div>
  );
}

function CashflowChart({
  forecast,
  comparison,
  minBuffer,
}: {
  forecast: ForecastDay[];
  comparison?: ForecastDay[];
  minBuffer: number;
}) {
  const all = [...forecast, ...(comparison || [])].map((d) => d.balance);
  const max = Math.max(...all, minBuffer),
    min = Math.min(...all, 0),
    range = Math.max(1, max - min);
  const width = 760,
    height = 190,
    pad = 18;
  const points = (rows: ForecastDay[]) =>
    rows
      .map(
        (d, i) =>
          `${pad + (i * (width - pad * 2)) / Math.max(1, rows.length - 1)},${pad + ((max - d.balance) * (height - pad * 2)) / range}`,
      )
      .join(" ");
  const dangerY = pad + ((max - minBuffer) * (height - pad * 2)) / range;
  return (
    <div className="chart-wrap">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        role="img"
        aria-label={`Cashflow forecast ending at ${formatINR((comparison || forecast).at(-1)?.balance || 0)}`}
      >
        <defs>
          <linearGradient id="area" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#0e5b3a" stopOpacity=".2" />
            <stop offset="1" stopColor="#0e5b3a" stopOpacity="0" />
          </linearGradient>
        </defs>
        <line
          x1={pad}
          x2={width - pad}
          y1={dangerY}
          y2={dangerY}
          className="threshold"
        />
        <text x={pad + 4} y={Math.max(12, dangerY - 7)} className="chart-label">
          ₹750 BUFFER
        </text>
        <polyline className="baseline" points={points(forecast)} />
        {comparison && (
          <polyline className="comparison" points={points(comparison)} />
        )}{" "}
        {forecast.map((d, i) => (
          <circle
            key={d.day}
            cx={
              pad + (i * (width - pad * 2)) / Math.max(1, forecast.length - 1)
            }
            cy={pad + ((max - d.balance) * (height - pad * 2)) / range}
            r={d.events.length ? 3 : 1.3}
            className={d.isDanger ? "danger-dot" : "event-dot"}
          >
            <title>{`Day ${d.day}: ${formatINR(d.balance)} ${d.events.join(", ")}`}</title>
          </circle>
        ))}
      </svg>
      <div className="chart-axis">
        <span>DAY {forecast[0]?.day}</span>
        <span>DAY {forecast.at(-1)?.day}</span>
      </div>
    </div>
  );
}

function Simulate({
  state,
  scenario,
  setScenario,
  result,
  onCommit,
}: {
  state: MoneyState;
  scenario: Scenario;
  setScenario: (s: Scenario) => void;
  result: ReturnType<typeof simulateDecision>;
  onCommit: () => void;
}) {
  const currencyDelta = result.after.monthEnd - result.before.monthEnd;
  const bad =
    currencyDelta < 0 ||
    result.after.safeDaily < result.before.safeDaily ||
    result.after.riskScore > result.before.riskScore;
  const fixedSubscriptionValue =
    scenario.kind === "pause_subscription" ||
    scenario.kind === "cancel_subscription";
  return (
    <div className="lab-layout">
      <section className="lab-builder">
        <div className="lab-intro">
          <span className="lab-badge">
            <FlaskConical size={16} /> CONSEQUENCE ENGINE
          </span>
          <h2>
            Test the decision.
            <br />
            <i>Keep your options.</i>
          </h2>
          <p>Nothing here touches your real month until you apply it.</p>
        </div>
        <p className="field-label">TRY A REAL-LIFE SCENARIO</p>
        <div className="preset-grid">
          {scenarioPresets.map((p) => (
            <button
              key={p.id}
              className={scenario.id === p.id ? "selected" : ""}
              onClick={() => setScenario(p)}
            >
              <span>
                {p.kind.includes("income") ||
                p.kind === "side_gig" ||
                p.kind === "pause_subscription" ||
                p.kind === "cancel_subscription"
                  ? "+"
                  : "−"}
                {formatINR(p.amount)}
              </span>
              <strong>{p.label}</strong>
              <ChevronRight size={16} />
            </button>
          ))}
        </div>
        <div className="custom-scenario">
          <p className="field-label">TUNE THIS DECISION</p>
          <label>
            {fixedSubscriptionValue ? "Subscription value" : "Amount"}{" "}
            <div className="money-input">
              <span>₹</span>
              <input
                type="number"
                min="0"
                disabled={fixedSubscriptionValue}
                value={scenario.amount / 100}
                onChange={(e) =>
                  setScenario({
                    ...scenario,
                    id: "custom",
                    amount: Math.round(Number(e.target.value) * 100),
                  })
                }
              />
            </div>
          </label>
          <label>
            Day{" "}
            <input
              type="range"
              min={state.profile.currentDay}
              max={state.profile.monthLength}
              value={scenario.day}
              onChange={(e) =>
                setScenario({
                  ...scenario,
                  id: "custom",
                  day: Number(e.target.value),
                })
              }
            />
            <span className="range-value">Day {scenario.day}</span>
          </label>
          <label className="check-row">
            <input
              type="checkbox"
              checked={!!scenario.includeShocks}
              onChange={(e) =>
                setScenario({ ...scenario, includeShocks: e.target.checked })
              }
            />
            <span>Include probability-weighted shocks</span>
          </label>
        </div>
      </section>
      <section className="lab-results">
        <div className="decision-head">
          <div>
            <p className="eyebrow">DECISION UNDER TEST</p>
            <h2>{scenario.label}</h2>
          </div>
          <div className={`verdict ${bad ? "bad" : "good"}`}>
            {bad ? <TrendingDown size={18} /> : <ShieldCheck size={18} />}{" "}
            {bad ? "WEAKENS MONTH" : "BUILDS BUFFER"}
          </div>
        </div>
        <div className="impact-hero">
          <div>
            <small>Month-end impact</small>
            <strong className={currencyDelta < 0 ? "negative" : "positive"}>
              {formatINR(currencyDelta, true)}
            </strong>
          </div>
          <p>{result.story}</p>
        </div>
        <CashflowChart
          forecast={result.baseline}
          comparison={result.scenarioForecast}
          minBuffer={state.profile.minimumBuffer}
        />
        <div className="chart-legend">
          <span>
            <i className="base-line"></i>Current path
          </span>
          <span>
            <i className="scenario-line"></i>With decision
          </span>
          <b>Hits on Day {scenario.day}</b>
        </div>
        <Comparison before={result.before} after={result.after} />
        <GoalImpactCard goalImpact={result.goalImpact || []} />
        <div className="consequence-note">
          <AlertTriangle size={20} />
          <div>
            <strong>{result.warnings[0]}</strong>
            <p>{result.recommendation}</p>
          </div>
        </div>
        <div className="lab-actions">
          <button
            className="secondary"
            onClick={() => setScenario(scenarioPresets[0])}
          >
            Discard
          </button>
          <button className="primary" onClick={onCommit}>
            Apply this decision <ArrowRight size={17} />
          </button>
        </div>
      </section>
    </div>
  );
}

function Comparison({
  before,
  after,
}: {
  before: ReturnType<typeof getMetrics>;
  after: ReturnType<typeof getMetrics>;
}) {
  const rows = [
    {
      l: "Balance now",
      a: before.currentBalance,
      b: after.currentBalance,
      m: "money",
      inverse: false,
    },
    {
      l: "Safe / day",
      a: before.safeDaily,
      b: after.safeDaily,
      m: "money",
      inverse: false,
    },
    {
      l: "Protected savings",
      a: before.protectedSavings,
      b: after.protectedSavings,
      m: "money",
      inverse: false,
    },
    {
      l: "Month-end",
      a: before.monthEnd,
      b: after.monthEnd,
      m: "money",
      inverse: false,
    },
    {
      l: "Runway",
      a: before.runway,
      b: after.runway,
      m: "days",
      inverse: false,
    },
    {
      l: "Risk",
      a: before.riskScore,
      b: after.riskScore,
      m: "score",
      inverse: true,
    },
    {
      l: "Health",
      a: before.healthScore,
      b: after.healthScore,
      m: "score",
      inverse: false,
    },
    {
      l: "Danger days",
      a: before.dangerDays,
      b: after.dangerDays,
      m: "days",
      inverse: true,
    },
  ] as const;
  return (
    <div className="compare-table" aria-label="Decision consequence comparison">
      <div className="compare-header">
        <span>THE RECEIPT</span>
        <span>BEFORE</span>
        <span>AFTER</span>
        <span>CHANGE</span>
      </div>
      {rows.map((r) => {
        const d = r.b - r.a,
          good = r.inverse ? d < 0 : d > 0;
        const fmt = (n: number) =>
          r.m === "money"
            ? formatINR(n)
            : `${n}${r.m === "days" ? " days" : ""}`;
        return (
          <div className="compare-row" key={r.l}>
            <strong>{r.l}</strong>
            <span>{fmt(r.a)}</span>
            <span>{fmt(r.b)}</span>
            <b className={d === 0 ? "neutral" : good ? "positive" : "negative"}>
              {d === 0
                ? "—"
                : `${d > 0 ? "+" : ""}${r.m === "money" ? formatINR(d) : d}`}
            </b>
          </div>
        );
      })}
    </div>
  );
}

function CalendarView({
  state,
  forecast,
  selectedDay,
  setSelectedDay,
  openAdd,
}: {
  state: MoneyState;
  forecast: ForecastDay[];
  selectedDay: number;
  setSelectedDay: (n: number) => void;
  openAdd: (v: "expense" | "income") => void;
}) {
  const row = forecast.find((f) => f.day === selectedDay);
  const completed = state.ledger.filter((t) => t.day === selectedDay);
  return (
    <div className="page-stack">
      <section className="calendar-hero">
        <div>
          <p className="eyebrow">YOUR WHOLE MONTH, NO SURPRISES</p>
          <h2>Tap a day. See what future-you faces.</h2>
        </div>
        <div className="calendar-summary">
          <small>First danger day</small>
          <strong>
            {getMetrics(state, forecast).nextDangerDay
              ? `Day ${getMetrics(state, forecast).nextDangerDay}`
              : "None"}
          </strong>
        </div>
      </section>
      <SpendingMatrix
        state={state}
        forecast={forecast}
        selectedDay={selectedDay}
        onSelectDay={setSelectedDay}
      />
      <section className="month-map">
        {Array.from({ length: 30 }, (_, i) => i + 1).map((day) => {
          const f = forecast.find((x) => x.day === day);
          const events = [
            ...state.commitments.filter((x) => x.day === day),
            ...state.subscriptions.filter(
              (x) => x.day === day && x.status === "active",
            ),
            ...state.ledger.filter((x) => x.day === day),
          ];
          return (
            <button
              key={day}
              className={`${selectedDay === day ? "selected" : ""} ${day < state.profile.currentDay ? "past" : f?.isDanger ? "danger" : f?.isLow ? "tight" : "safe"}`}
              onClick={() => setSelectedDay(day)}
            >
              <span>DAY {day}</span>
              <strong>
                {f
                  ? formatINR(f.balance)
                  : day === state.profile.currentDay
                    ? formatINR(getMetrics(state).currentBalance)
                    : "Cleared"}
              </strong>
              <div>
                {events.slice(0, 2).map((e) => (
                  <i key={e.id}>{e.label}</i>
                ))}
                {events.length > 2 && <i>+{events.length - 2} more</i>}
              </div>
            </button>
          );
        })}
      </section>
      <section className="day-drawer">
        <div className="date-box large">
          <strong>{selectedDay}</strong>
          <small>DAY</small>
        </div>
        <div className="day-copy">
          <p className="eyebrow">DAY DETAIL</p>
          <h3>
            {row
              ? `${formatINR(row.balance)} projected after today`
              : `Day ${selectedDay} is already in the books.`}
          </h3>
          <p>
            {row?.events.length
              ? row.events.join(" · ")
              : completed.length
                ? completed.map((t) => t.label).join(" · ")
                : "No bills or income scheduled. Just the daily spending plan."}
          </p>
        </div>
        <div className="day-buttons">
          <button className="secondary" onClick={() => openAdd("income")}>
            <Plus size={16} /> Income
          </button>
          <button className="primary" onClick={() => openAdd("expense")}>
            <Plus size={16} /> Expense
          </button>
        </div>
      </section>
    </div>
  );
}

function GoalsSubs({
  state,
  updateState,
}: {
  state: MoneyState;
  updateState: (fn: (s: MoneyState) => MoneyState, msg: string) => void;
}) {
  const activeCost = state.subscriptions
    .filter((s) => s.status === "active")
    .reduce((n, s) => n + s.amount, 0);
  return (
    <div className="page-stack">
      <section className="goals-header">
        <div>
          <p className="eyebrow">MONEY WITH A JOB</p>
          <h2>
            Protect what matters.
            <br />
            <i>Question what repeats.</i>
          </h2>
        </div>
        <div className="sub-total">
          <small>Subscriptions this month</small>
          <strong>{formatINR(activeCost)}</strong>
          <span>
            {Math.ceil(
              activeCost / Math.max(1, state.profile.plannedDailySpend),
            )}{" "}
            days of planned spending
          </span>
        </div>
      </section>
      <GoalLockboxSimulator state={state} updateState={updateState} />
      <section>
        <div className="section-title">
          <div>
            <p className="eyebrow">GOALS</p>
            <h2>Future-you’s envelopes</h2>
          </div>
        </div>
        <div className="goal-grid">
          {state.goals.map((g) => {
            const pct = Math.min(100, Math.round((g.saved / g.target) * 100));
            return (
              <article className="goal-card" key={g.id}>
                <div className="goal-top">
                  <div className="goal-icon">
                    <Target size={21} />
                  </div>
                  <span className={g.protected ? "protected" : "flexible"}>
                    {g.protected ? <ShieldCheck size={13} /> : null}
                    {g.protected ? "PROTECTED" : "FLEXIBLE"}
                  </span>
                </div>
                <h3>{g.label}</h3>
                <p>{g.note}</p>
                <div className="progress">
                  <span style={{ width: `${pct}%` }}></span>
                </div>
                <div className="goal-numbers">
                  <strong>{formatINR(g.saved)}</strong>
                  <span>of {formatINR(g.target)}</span>
                  <b>{pct}%</b>
                </div>
                <button
                  className="secondary full"
                  onClick={() =>
                    updateState((s) => {
                      const goal = s.goals.find((x) => x.id === g.id)!;
                      goal.saved += 10000;
                      s.ledger.unshift({
                        id: `goal-${Date.now()}`,
                        label: `Added to ${g.label}`,
                        amount: 10000,
                        day: s.profile.currentDay,
                        category: "savings",
                        type: "savings_contribution",
                        status: "completed",
                        essential: false,
                      });
                      return s;
                    }, `₹100 moved to ${g.label}.`)
                  }
                >
                  <Plus size={16} /> Add ₹100
                </button>
              </article>
            );
          })}
        </div>
      </section>
      <section>
        <div className="section-title">
          <div>
            <p className="eyebrow">RECURRING COSTS</p>
            <h2>Small leaks, every month</h2>
          </div>
          <span>
            {state.subscriptions.filter((s) => s.status === "active").length}{" "}
            active
          </span>
        </div>
        <div className="subs-list">
          {state.subscriptions.map((sub) => (
            <div className="sub-row" key={sub.id}>
              <div className="sub-logo">{sub.label.slice(0, 1)}</div>
              <div>
                <strong>{sub.label}</strong>
                <small>
                  Due Day {sub.day} · {categoryLabels[sub.category]}
                </small>
              </div>
              <b>{formatINR(sub.amount)}</b>
              <span className={`status ${sub.status}`}>{sub.status}</span>
              <button
                className="secondary"
                onClick={() =>
                  updateState(
                    (s) => {
                      const x = s.subscriptions.find((v) => v.id === sub.id)!;
                      x.status = x.status === "active" ? "paused" : "active";
                      return s;
                    },
                    sub.status === "active"
                      ? `${sub.label} paused. ${formatINR(sub.amount)} returned to the forecast.`
                      : `${sub.label} resumed.`,
                  )
                }
              >
                {sub.status === "active" ? (
                  <>
                    <Pause size={15} />
                    Pause
                  </>
                ) : (
                  <>
                    <Play size={15} />
                    Resume
                  </>
                )}
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function Ledger({
  state,
  updateState,
  onExport,
  onImport,
  onReset,
  openAdd,
}: {
  state: MoneyState;
  updateState: (fn: (s: MoneyState) => MoneyState, msg: string) => void;
  onExport: () => void;
  onImport: () => void;
  onReset: () => void;
  openAdd: (v: "expense" | "income") => void;
}) {
  const [filter, setFilter] = useState("all"),
    [query, setQuery] = useState("");
  const all = [
    ...state.ledger,
    ...state.commitments.map((c) => ({
      id: c.id,
      label: c.label,
      amount: c.amount,
      day: c.day,
      category: c.category,
      type: "commitment_payment" as TransactionType,
      status:
        c.status === "paid" ? ("completed" as const) : ("upcoming" as const),
      essential: c.essential,
    })),
  ].sort((a, b) => b.day - a.day);
  const rows = all.filter(
    (t) =>
      (filter === "all" ||
        (filter === "income" && t.type === "income") ||
        (filter === "expenses" && t.type !== "income") ||
        (filter === "upcoming" && t.status === "upcoming")) &&
      t.label.toLowerCase().includes(query.toLowerCase()),
  );
  return (
    <div className="page-stack">
      <section className="ledger-head">
        <div>
          <p className="eyebrow">EVERY RUPEE, ACCOUNTED FOR</p>
          <h2>The month’s paper trail</h2>
        </div>
        <div className="ledger-actions">
          <button className="secondary" onClick={onExport}>
            <Download size={16} /> Export
          </button>
          <button className="secondary" onClick={onImport}>
            <Upload size={16} /> Import
          </button>
          <button className="secondary danger-text" onClick={onReset}>
            <RotateCcw size={16} /> Reset demo
          </button>
        </div>
      </section>
      <section className="ledger-card">
        <div className="ledger-toolbar">
          <div className="filters">
            {["all", "expenses", "income", "upcoming"].map((f) => (
              <button
                key={f}
                className={filter === f ? "active" : ""}
                onClick={() => setFilter(f)}
              >
                {f}
              </button>
            ))}
          </div>
          <label className="search">
            <Search size={16} />
            <input
              placeholder="Search the ledger"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </label>
          <button className="primary" onClick={() => openAdd("expense")}>
            <Plus size={16} /> Add
          </button>
        </div>
        <div className="ledger-table">
          <div className="ledger-table-head">
            <span>DETAIL</span>
            <span>DAY</span>
            <span>STATUS</span>
            <span>AMOUNT</span>
            <span></span>
          </div>
          {rows.map((t) => {
            const positive =
              t.type === "income" ||
              t.type === "goal_withdrawal" ||
              t.type === "loan_received";
            return (
              <div className="ledger-row" key={t.id}>
                <div className={`category-dot ${t.category}`}>
                  {positive ? (
                    <ArrowDownRight size={17} />
                  ) : (
                    <ArrowUpRight size={17} />
                  )}
                </div>
                <div>
                  <strong>{t.label}</strong>
                  <small>{categoryLabels[t.category]}</small>
                </div>
                <span>Day {t.day}</span>
                <span className={`status ${t.status}`}>{t.status}</span>
                <b className={positive ? "positive" : ""}>
                  {positive ? "+" : "−"}
                  {formatINR(t.amount)}
                </b>
                <button
                  className="delete"
                  aria-label={`Delete ${t.label}`}
                  onClick={() =>
                    updateState(
                      (s) => ({
                        ...s,
                        ledger: s.ledger.filter((x) => x.id !== t.id),
                        commitments: s.commitments.filter((x) => x.id !== t.id),
                      }),
                      `${t.label} removed.`,
                    )
                  }
                >
                  <Trash2 size={16} />
                </button>
              </div>
            );
          })}
          {!rows.length && (
            <div className="empty">No money moves match that filter.</div>
          )}
        </div>
      </section>
      <section className="decision-log">
        <div className="section-title compact">
          <div>
            <p className="eyebrow">DECISION LOG</p>
            <h2>Choices you made on purpose</h2>
          </div>
        </div>
        {state.decisionsLog.map((d) => (
          <div key={d.id}>
            <History size={17} />
            <span>
              <strong>{d.label}</strong>
              <small>{d.consequence}</small>
            </span>
            <b>Day {d.day}</b>
          </div>
        ))}
      </section>
    </div>
  );
}

function AddTransaction({
  mode,
  day,
  currentDay,
  onClose,
  onAdd,
}: {
  mode: "expense" | "income";
  day: number;
  currentDay: number;
  onClose: () => void;
  onAdd: (t: Transaction) => void;
}) {
  const [label, setLabel] = useState(""),
    [amount, setAmount] = useState(""),
    [category, setCategory] = useState<Category>(
      mode === "income" ? "income" : "food",
    ),
    [essential, setEssential] = useState(false);
  const dialogRef = useModalDialog<HTMLFormElement>(onClose);
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericAmount = Number(amount);
    if (
      !label.trim() ||
      !Number.isFinite(numericAmount) ||
      numericAmount <= 0 ||
      numericAmount > 10000000
    )
      return;
    onAdd({
      id: `manual-${Date.now()}`,
      label: label.trim().slice(0, 120),
      amount: Math.round(numericAmount * 100),
      day,
      category,
      type: mode === "income" ? "income" : "expense",
      status: day <= currentDay ? "completed" : "upcoming",
      essential,
    });
  };
  return (
    <div
      className="modal-backdrop"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <form
        ref={dialogRef}
        className="modal"
        onSubmit={submit}
        role="dialog"
        aria-modal="true"
        aria-labelledby="transaction-title"
        tabIndex={-1}
      >
        <button
          type="button"
          className="modal-close"
          onClick={onClose}
          aria-label="Close transaction dialog"
        >
          <X size={19} aria-hidden="true" />
        </button>
        <span className="lab-badge">
          {mode === "income" ? (
            <HandCoins size={16} aria-hidden="true" />
          ) : (
            <WalletCards size={16} aria-hidden="true" />
          )}{" "}
          QUICK ENTRY
        </span>
        <h2 id="transaction-title">Add {mode}</h2>
        <p>
          {day > currentDay
            ? `Scheduled for Day ${day}. Today’s balance will stay untouched.`
            : "This changes the real month, not a simulation."}
        </p>
        <label>
          Description
          <input
            autoFocus
            maxLength={120}
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder={
              mode === "income" ? "Freelance payment" : "What did you pay for?"
            }
            required
          />
        </label>
        <label>
          Amount
          <div className="money-input">
            <span aria-hidden="true">₹</span>
            <input
              type="number"
              min="1"
              max="10000000"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0"
              required
            />
          </div>
        </label>
        <label>
          Category
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as Category)}
          >
            {Object.entries(categoryLabels).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
        </label>
        {mode === "expense" && (
          <label className="check-row">
            <input
              type="checkbox"
              checked={essential}
              onChange={(e) => setEssential(e.target.checked)}
            />
            <span>This was essential</span>
          </label>
        )}
        <button className="primary full" type="submit">
          {day > currentDay ? "Schedule in ledger" : "Add to ledger"}{" "}
          <ArrowRight size={17} aria-hidden="true" />
        </button>
      </form>
    </div>
  );
}

function DecisionReceipt({
  result,
  scenario,
  onClose,
}: {
  result: ReturnType<typeof simulateDecision>;
  scenario: Scenario;
  onClose: () => void;
}) {
  const riskDelta = result.after.riskScore - result.before.riskScore;
  const positive =
    scenario.kind.includes("income") ||
    scenario.kind === "side_gig" ||
    scenario.kind === "pause_subscription" ||
    scenario.kind === "cancel_subscription";
  const dialogRef = useModalDialog<HTMLDivElement>(onClose);
  return (
    <div className="modal-backdrop">
      <div
        ref={dialogRef}
        className="modal receipt-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="receipt-title"
        tabIndex={-1}
      >
        <button
          className="modal-close"
          onClick={onClose}
          aria-label="Close decision receipt"
        >
          <X size={19} aria-hidden="true" />
        </button>
        <div className="receipt-check">
          <Check size={28} aria-hidden="true" />
        </div>
        <p className="eyebrow">DECISION RECEIPT · DAY {scenario.day}</p>
        <h2 id="receipt-title">
          Choice applied.
          <br />
          Here’s what changed.
        </h2>
        <div className="receipt-paper">
          <div>
            <span>{scenario.label}</span>
            <strong>
              {positive ? "+" : "−"}
              {formatINR(scenario.amount)}
            </strong>
          </div>
          <hr />
          <div>
            <span>Daily allowance</span>
            <strong>
              {formatINR(result.before.safeDaily)} →{" "}
              {formatINR(result.after.safeDaily)}
            </strong>
          </div>
          <div>
            <span>Protected savings</span>
            <strong>{formatINR(result.after.protectedSavings)}</strong>
          </div>
          <div>
            <span>Month-end</span>
            <strong>{formatINR(result.after.monthEnd)}</strong>
          </div>
          <div>
            <span>Risk movement</span>
            <strong className={riskDelta > 0 ? "negative" : "positive"}>
              {riskDelta > 0 ? "+" : ""}
              {riskDelta} points
            </strong>
          </div>
        </div>
        <p className="receipt-story">{result.story}</p>
        <button className="primary full" onClick={onClose}>
          Back to the month
        </button>
      </div>
    </div>
  );
}
